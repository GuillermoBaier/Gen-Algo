var cities = [];
var totalCities = 20;

var popSize = 1000;
var population = [];
var fitness = [];

var recordDistance = Infinity;
var fittestEver;
var currentFittest;

var stateP;

function setup() {

  createCanvas(1600, 1600);

  var order = [];
  
  for (var i = 0; i < totalCities; i++) {

      var v = createVector(random(width), random(height / 2));
      cities[i] = v;
      order[i] = i;
  
                                        }

  for (var i = 0; i < popSize; i++) {

    population[i] = shuffle(order);
  
                                    }


  stateP = createP('').style('font-size', '32pt');
  
}

function draw() {
 
  background(0);

  // Genetic Algorithm

  calculateFitness();
  normalizeFitness();
  nextGeneration();

  stroke(255);
  strokeWeight(4);
  noFill();
  beginShape();

  for (var i = 0; i < fittestEver.length; i++) {
   
      var n = fittestEver[i];
      vertex(cities[n].x, cities[n].y);
      ellipse(cities[n].x, cities[n].y, 16, 16);

                                               }
  
  endShape();

  translate(0, height / 2);
  stroke(255);
  strokeWeight(4);
  noFill();
  beginShape();
  for (var i = 0; i < currentFittest.length; i++) {

      var n = currentFittest[i];
      vertex(cities[n].x, cities[n].y);
      ellipse(cities[n].x, cities[n].y, 16, 16);
  
                                                  }
  
  endShape();

}

function swap(a, i, j) {
  
    var temp = a[i];
    a[i] = a[j];
    a[j] = temp;

                       }

function calcDistance(points, order) {
 
  var sum = 0;
 
  for (var i = 0; i < order.length - 1; i++) {
  
      var cityAIndex = order[i];
      var cityA = points[cityAIndex];
      var cityBIndex = order[i + 1];
      var cityB = points[cityBIndex];
      var d = dist(cityA.x, cityA.y, cityB.x, cityB.y);
      sum += d;
                                             }

  return sum;

                                      }
